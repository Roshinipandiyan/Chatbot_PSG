package com.example.chatbotpsg

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
