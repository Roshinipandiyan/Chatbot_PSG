import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:speech_to_text/speech_to_text.dart' as stt;
import 'package:galli_text_to_speech/text_to_speech.dart' as tts;

void main() => runApp(ChatApp());

class ChatApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: ChatScreen(),
    );
  }
}

class ChatScreen extends StatefulWidget {
  @override
  _ChatScreenState createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final List<String> messages = [];
  final TextEditingController textEditingController = TextEditingController();
  final ScrollController _scrollController = ScrollController();
  final stt.SpeechToText speech = stt.SpeechToText();
  final tts.TextToSpeech textToSpeech = tts.TextToSpeech();

  Future<String> sendMessage(String text) async {
    if (text.isEmpty) return "Input is empty";

    String url = "http://10.0.2.2:5000/query";

    try {
      // Prepare the JSON payload
      Map<String, String> payload = {
        'query': text,
      };

      // Convert payload to JSON
      String jsonString = json.encode(payload);

      // Make the POST request
      http.Response response = await http.post(
        Uri.parse(url),
        headers: <String, String>{
          'Content-Type': 'application/json; charset=UTF-8',
        },
        body: jsonString,
      );

      // Check the response status
      if (response.statusCode == 200) {
        // Parse the JSON response
        Map<String, dynamic> responseBody = json.decode(response.body);
        return responseBody['answer'] ?? "No answer received from the server.";
      } else {
        return "Failed to fetch response. Status code: ${response.statusCode}";
      }
    } catch (e) {
      return "Error occurred while fetching response: $e";
    }
  }

  Future<String> sendMessageAndUpdateUI(String text) async {
    setState(() {
      messages.add("You: $text");
    });
    textEditingController.clear();

    String botResponse = await sendMessage(text);

    setState(() {
      messages.add("Bot: $botResponse");
    });

    await textToSpeech.speak(botResponse); // Speak the bot response

    // Scroll to bottom after adding new messages
    _scrollController.animateTo(
      _scrollController.position.maxScrollExtent,
      duration: Duration(milliseconds: 300),
      curve: Curves.easeOut,
    );

    return botResponse; // Return the bot response
  }

  void startListening() {
    speech.listen(onResult: (result) {
      setState(() {
        textEditingController.text = result.recognizedWords;
      });
    });
  }

  void stopListening() {
    speech.stop();
  }

  @override
  void initState() {
    super.initState();
    speech.initialize();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Chatbot'),
        backgroundColor: Colors.blueGrey, // Change app bar color
      ),
      body: Container(
        decoration: BoxDecoration(
          image: DecorationImage(
            image: AssetImage(
                "assets/psglogo1.png"), // Provide the path to your background image
            fit: BoxFit.cover,
          ),
        ),
        child: Column(
          children: <Widget>[
            Expanded(
              child: ListView.builder(
                controller: _scrollController,
                itemCount: messages.length,
                itemBuilder: (context, index) => Padding(
                  padding: EdgeInsets.symmetric(vertical: 4.0, horizontal: 8.0),
                  child: Align(
                    alignment: messages[index].startsWith("You")
                        ? Alignment.centerRight
                        : Alignment.centerLeft,
                    child: Container(
                      padding: EdgeInsets.all(8.0),
                      decoration: BoxDecoration(
                        color: messages[index].startsWith("You")
                            ? Colors.blueGrey
                            : Colors.green,
                        borderRadius: BorderRadius.circular(12.0),
                      ),
                      child: Text(
                        messages[index],
                        style: TextStyle(color: Colors.white),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Row(
                children: <Widget>[
                  Expanded(
                    child: TextField(
                      controller: textEditingController,
                      decoration: InputDecoration(
                        hintText: "Send a message",
                        filled: true,
                        fillColor: Colors.white,
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(30.0),
                        ),
                      ),
                    ),
                  ),
                  SizedBox(width: 8.0),
                  Material(
                    color: Colors.green, // Change send icon color to green
                    borderRadius: BorderRadius.circular(30.0),
                    child: InkWell(
                      onTap: () async {
                        String botResponse = await sendMessageAndUpdateUI(
                            textEditingController.text);
                        // Handle bot response here if needed
                      },
                      borderRadius: BorderRadius.circular(30.0),
                      child: Padding(
                        padding: const EdgeInsets.all(12.0),
                        child: Icon(
                          Icons.send,
                          color: Colors.white,
                        ),
                      ),
                    ),
                  ),
                  SizedBox(width: 8.0),
                  Material(
                    color: Colors.blue, // Change voice icon color to blue
                    borderRadius: BorderRadius.circular(30.0),
                    child: InkWell(
                      onTap: () {
                        if (!speech.isListening) {
                          startListening();
                        } else {
                          stopListening();
                        }
                      },
                      borderRadius: BorderRadius.circular(30.0),
                      child: Padding(
                        padding: const EdgeInsets.all(12.0),
                        child: Icon(
                          Icons.mic,
                          color: Colors.white,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
